import boto3

# Encapsulate functionality related to text recognition
class RecognitionService:
    def __init__(self, storage_service):
        self.client = boto3.client('rekognition') # Create a boto3 Rekognition client
        # Retrieve bucket name from storage_service object's
        # get_storage_location method (the bucket name would have
        # been passed to StorageService)
        self.bucket_name = storage_service.get_storage_location() # Dependency injection

    # file_name is the name of the file in the S3 bucket
    def detect_text(self, file_name):
        # Call boto3's Rekognition client's detect_text method and
        # pass the S3 object reference
        response = self.client.detect_text(
            Image = {
                'S3Object': {
                    'Bucket': self.bucket_name,
                    'Name': file_name
                }
            }
        )

        lines = []
        # Within response is the TextDetections array
        for detection in response['TextDetections']:
            if detection['Type'] == 'LINE':
                lines.append({
                    'text': detection['DetectedText'],
                    'confidence': detection['Confidence'],
                    'boundingBox': detection['Geometry']['BoundingBox'] # boundingBox is a coarse rectangle of where the text is located in the image
                })

        # Return a list of dictionaries of the 
        # text, confidence, and bounding box
        return lines


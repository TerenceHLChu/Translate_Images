import boto3

# Encapsulate functionality related to text translation
class TranslationService:
    def __init__(self):
        self.client = boto3.client('translate') # Create a boto3 Translate client

    def translate_text(self, text, source_language = 'auto', target_language = 'en'):
        # Call boto3's Translate client's translate_text method
        # and passes in the text, source language, and target language
        response = self.client.translate_text(
            Text = text,
            SourceLanguageCode = source_language,
            TargetLanguageCode = target_language
        )
        
        # Process the response and extract the translated text,
        # source language, and target language
        translation = {
            'translatedText': response['TranslatedText'],
            'sourceLanguage': response['SourceLanguageCode'],
            'targetLanguage': response['TargetLanguageCode']
        }

        # Returns a dictionary of the translated text,
        # source language, and target language
        return translation

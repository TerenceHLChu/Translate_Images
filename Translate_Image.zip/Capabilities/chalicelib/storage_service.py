# Provides an easy-to-use interface for interacting with AWS services 
import boto3

# Wrapper around S3
class StorageService:
    def __init__(self, storage_location): # Class accepts one parameter
        self.client = boto3.client('s3') # Create a boto3 S3 client
        self.bucket_name = storage_location

    def get_storage_location(self):
        return self.bucket_name

    # file_bytes is the contents of the file as byte
    def upload_file(self, file_bytes, file_name):
        # boto3's S3 client's put_object method uploads file
        # to bucket_name and sets the ACL to make it
        # publicly readable
        self.client.put_object(Bucket = self.bucket_name,
                               Body = file_bytes,
                               Key = file_name,
                               ACL = 'public-read')
        
        # Return a dictionary of the file name and the storage location
        # Since the ACL is set to public-read, anyone with this URL can see this file on the internet
        return {'fileId': file_name,
                'fileUrl': "http://" + self.bucket_name + ".s3.amazonaws.com/" + file_name}

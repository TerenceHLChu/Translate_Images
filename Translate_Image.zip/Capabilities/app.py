from chalice import Chalice
from chalicelib import storage_service # Import service implementation layer
from chalicelib import recognition_service # Import service implementation layer
from chalicelib import translation_service # Import service implementation layer

import base64
import json

#####
# chalice app configuration
#####
app = Chalice(app_name='Capabilities') # Create a new Chalice app named Capabilities
app.debug = True # Provides more detailed logging information during development

#####
# services initialization
#####
storage_location = 'contentcen301220117.aws.ai'

# Instantiate a StorageService object and pass to it storage_location
storage_service = storage_service.StorageService(storage_location)

# Instantiate a RecognitionService object and pass to it storage_service
recognition_service = recognition_service.RecognitionService(storage_service)

# Instantiate a TranslationService object
translation_service = translation_service.TranslationService()

#####
# RESTful endpoints
#####
# When a POST request is sent to the route, /images, upload_image is executed
@app.route('/images', methods = ['POST'], cors = True)
def upload_image(): # RESTful endpoint (accessed by HTTP request)
    """processes file upload and saves file to storage service"""
    # Retrieve the raw HTTP request body sent by the client so that it can be parsed
    request_data = json.loads(app.current_request.raw_body)
    
    # Get file name
    file_name = request_data['filename']
    
    # Get file bytes Base64 encoding translates binary data, such as image
    # and audio, into ASCII string format and back.
    # (Takes base64-encoded string (from the request body) and returns the binary data)
    file_bytes = base64.b64decode(request_data['filebytes']) 
                                                            
    # Call the storage_service object's upload_file method to upload the file
    # Pass in the file bytes and name extracted above
    image_info = storage_service.upload_file(file_bytes, file_name)

    # image_info is constructed in the previous line
    # upload_file returns a dictionary of the file name and the storage location
    # Therefore, image_info returns the same 
    # Chalice will automatically format this as JSON
    return image_info

# When a POST request is sent to the route, /images/{image_id}/translate-text,
# translate_image_text is executed
@app.route('/images/{image_id}/translate-text', methods = ['POST'], cors = True)
def translate_image_text(image_id): # RESTful endpoint (accessed by HTTP request)

    print(image_id)

    """detects then translates text in the specified image"""
    # Retrieve the raw HTTP request body sent by the client so that it can be parsed
    request_data = json.loads(app.current_request.raw_body)
    
    # Extract the source and target language
    from_lang = request_data['fromLang']
    to_lang = request_data['toLang']

    MIN_CONFIDENCE = 80.0

    # Pass the image name to recognition_service's detect_text method
    # The variable, text_lines, will store a dictionary holding the text in the image,
    # the confidence, and bounding box
    text_lines = recognition_service.detect_text(image_id)

    translated_lines = []
    for line in text_lines:
        # Check confidence
        if float(line['confidence']) >= MIN_CONFIDENCE:
            # Call translation_service's translate_text method to translate the text
            translated_line = translation_service.translate_text(line['text'], from_lang, to_lang)
            translated_lines.append({
                'text': line['text'], # from text_lines
                'translation': translated_line, # from translation_service.translate_text
                'boundingBox': line['boundingBox'] # from text_lines
            })
    
    # Chalice will automatically format this as JSON
    print(translated_lines)
    return translated_lines


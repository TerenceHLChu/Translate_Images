"use strict";

const serverUrl = "http://127.0.0.1:8000";

async function uploadImage() {
    // Encode input file as base64 string for upload
	// document.getElementById("file") = the first input element (file upload input field) (i.e., id="file")
	// .files[0] = takes the first element in files
    let file = document.getElementById("file").files[0];
    let converter = new Promise(function(resolve, reject) {
        const reader = new FileReader();
        reader.readAsDataURL(file);  // FileReader reads the contents of the file as a data URL (base64 encoded)
        reader.onload = () => resolve(reader.result
            .toString().replace(/^data:(.*,)?/, ''));
        reader.onerror = (error) => reject(error);
    });
	// Wait for the file to be fully read (and encoded as a base64 string)
	// encodedString will hold the base64-encoded string
    let encodedString = await converter;

    // Clear the first input element (file upload input field) (i.e, id="file")
    document.getElementById("file").value = "";

    // Make server call to upload image and return the server upload promise
	// Make a fetch reques to upload image
	// Send a POST request to /images endpoint with filename and filebytes
	// POST means that client is sending data to the server
    return fetch(serverUrl + "/images", {
        method: "POST",
        headers: {
            'Accept': 'application/json', // Server should respond with JSON
            'Content-Type': 'application/json' //JSON to be sent to server (i.e., server should expect JSON) 
        },
        body: JSON.stringify({filename: file.name, filebytes: encodedString})
	// Handle the response from the server
    }).then(response => {
        if (response.ok) {
			// Parses response body as JSON and returns it
			// JSON contains the filename (fileID) and storage location (fileURL)
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function updateImage(image) {
	// id="view?
	// Make element visible
	// The element was initially inivisble in the HTML
    document.getElementById("view").style.display = "block";

	// id="image"
    let imageElem = document.getElementById("image");
    imageElem.src = image["fileUrl"];
    imageElem.alt = image["fileId"];

    return image;
}

function translateImage(image) {
    // Make server call to translate image and return the server upload promise
	// Make a fetch reques to translate the image
	// Send a POST request to /images/{image_id}/translate-text endpoint with fromLang and toLang
	// POST means that client is sending data to the server
	// {image_id} is the image["fileId"] variable returned from the uploadImage function
	return fetch(serverUrl + "/images/" + image["fileId"] + "/translate-text", {
        method: "POST",
        headers: {
            'Accept': 'application/json', // Server should respond with JSON
            'Content-Type': 'application/json' //JSON to be sent to server (i.e., server should expect JSON)
        },
        body: JSON.stringify({fromLang: "auto", toLang: "en"})
    }).then(response => {
        if (response.ok) {
			// Parses response body as JSON and returns it
			// JSON contains a list of dictionaries containing text, translation, and boundingBox
			// and a second list of dictionaries holding the output_file_paths
            // It is in the format of an array
			return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function annotateImage(translations) {
    let translationsElem = document.getElementById("translations");
	
		// Remove all child nodes of translationsElem and clear all previous translations
    while (translationsElem.firstChild) {
        translationsElem.removeChild(translationsElem.firstChild);
    }
    translationsElem.clear
	
	// translate_image_text method in app.py returns a list of dictionaries
	// Each dictionary holds "text", "translation", and "bounding box"
    for (let i = 0; i < translations.length; i++) {
        let translationElem = document.createElement("h6"); // Create an h6 heading
        translationElem.appendChild(document.createTextNode( // Display translation under h6 heading
			// translation[i]["translation"] references a dictionary object 
			// To get the translation, the dictionary object's translatedText must be referenced 
            translations[i]["text"] + " -> " + translations[i]["translation"]["translatedText"]
        ));
        translationsElem.appendChild(document.createElement("hr")); // Draw a horizonal line
        translationsElem.appendChild(translationElem); // Append the the above h6 element
    }
}

// The upload button in the HTML calls this function
// Call functions sequentially 
function uploadAndTranslate() {
    uploadImage()
        .then(image => updateImage(image))
        .then(image => translateImage(image))
        .then(translations => annotateImage(translations))
        .catch(error => {
            alert("Error: " + error);
        })
}

class HttpError extends Error {
    constructor(response) {
        super(`${response.status} for ${response.url}`);
        this.name = "HttpError";
        this.response = response;
    }
}